//
//  exbankcardcore.h
//  exbankcardcore
//
//  Created by zybgod on 15-3-25.
//  Copyright (c) 2015年 exocr. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface exbankcardcore : NSObject

@end
