//
//  WYIDDownViewController.h
//  WYIDCardOCR
//
//  Created by 汪年成 on 17/7/7.
//  Copyright © 2017年 之静之初. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WYScanResultModel.h"

@interface WYIDDownViewController : UIViewController

@property (nonatomic, strong) WYScanResultModel *resultModel;

@end
